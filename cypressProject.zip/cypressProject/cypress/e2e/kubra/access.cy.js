// First Test to access Kubra website
describe('Access website', () => {
    beforeEach(() => {
        //Access Kubra website before each function
        const accessPage = "https://www.kubra.com"
        cy.visit(accessPage);
    })

    it('Assert visiting correct page', () => {
        //Assert that we visit the right page
        cy.url().should('include', 'kubra');
        cy.contains('Kubra');
    })

    it('Explore KUBRA Solutions', () => {
        const accessWord = 'KUBRA';
        const accessLink = 'Explore ' + accessWord + ' Solutions';
        cy.get('.button').contains(accessLink).click();
        //Assert that the button is clicked
        cy.contains(accessWord);

    });

    it('Visit the Careers page', () => {
        cy.get('.contact-us').click();
        //Assert that the button is clicked
        cy.contains('Careers');
    });
})